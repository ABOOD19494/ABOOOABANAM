def func():
    x = 1
    class my_class:
        y = x
